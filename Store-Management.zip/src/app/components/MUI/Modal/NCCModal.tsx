'use client';
import { Modal, Form, Button } from 'react-bootstrap';
import { useState } from 'react';
import { useEffect } from 'react';

interface ModalFormProps {
    show: boolean;
    handleClose: () => void;
    mode: 'add' | 'edit' | 'delete';     // chế độ: thêm hay sửa
    NCCData?: any;           // dữ liệu cũ khi sửa
}

export default function ModalForm({ show, handleClose, mode, NCCData }: ModalFormProps) {
    const [formData, setFormData] = useState({ tenNcc: '' });

    // Nếu là edit thì khi mở modal, nạp sẵn dữ liệu vào form
    useEffect(() => {
        if(mode === "add" && NCCData){

        }else if(mode === "edit" && NCCData){
            
            setFormData(NCCData);
        }
        else  {
            setFormData(NCCData);
        }     
    }, [mode, NCCData]);

    // handle submit xác định nút đó là add hay sửa
    const handleSubmit = () => {
        if (mode === "add") {
            console.log("thêm", formData);
            // call POST API
        } else if(mode === "edit") {
            console.log("sửa", formData);
            // call PUT API
        } else{
            console.log("xóa", formData);
            // call PUT API
        }
        handleClose();
    };

    return (
        <Modal show={show} onHide={handleClose} centered>
            <Modal.Header closeButton>
                <Modal.Title>
                    {mode === "add" ? "Thêm Nhà cung cấp" : "Sửa Nhà cung cấp"}
                </Modal.Title>
            </Modal.Header>
            <Modal.Body>
                <Form onSubmit={handleSubmit}>
                    <Form.Group className="mb-3">
                        <Form.Label>Tên Nhà cung cấp</Form.Label>
                        <Form.Control
                            type="text"
                            //   value={formData.name}
                            //   onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                            placeholder='Nhập tên nhà cung cấp'

                        />
                    </Form.Group>

                    {/* tui lấy trường này ví dụ cho mng làm cái nút edit chứ thật chất ko có  */}

                    {mode === "edit" && (
                        <Form.Group className="mb-3">
                            <Form.Label>Trạng thái</Form.Label>
                            <Form.Select aria-label="Default select example">
                                <option>Open this select menu</option>
                                <option value="1">One</option>
                                <option value="2">Two</option>
                                <option value="3">Three</option>
                            </Form.Select>
                        </Form.Group>
                    )}

                    <div className="text-end">
                        <Button variant="secondary" onClick={handleClose} className="me-2">
                            Hủy
                        </Button>
                        <Button variant="success" type="submit">
                            {mode === "add" ? "Thêm mới" : "Cập nhật"}
                        </Button>
                    </div>
                </Form>
            </Modal.Body>
        </Modal>
    );
}
