export default function SanPham() {
    return (
        <div>vo trang SanPham</div>
    );
}