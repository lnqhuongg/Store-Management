(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_3da3ce50._.css",
  "static/chunks/_3d3eb209._.js"
],
    source: "dynamic"
});
